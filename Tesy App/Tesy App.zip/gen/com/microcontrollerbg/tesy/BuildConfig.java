/** Automatically generated file. DO NOT MODIFY */
package com.microcontrollerbg.tesy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}