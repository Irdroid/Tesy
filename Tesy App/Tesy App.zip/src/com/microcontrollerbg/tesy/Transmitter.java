package com.microcontrollerbg.tesy;

public abstract class Transmitter {

	protected Transmitter() {
	}
}